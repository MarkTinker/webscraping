<title>.::elbruninh::.</title>
<div class="header">
	<div class="logo"><a href="/admini"><img src="imagenes/logo.jpg" width="230" height="120" border="0" /></a></div>
  <div class="site_name"></div>
</div>