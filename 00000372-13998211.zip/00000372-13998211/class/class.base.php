<?php
class Base {
	var $_select=0;
	function existe(){
		return $this->_select;
	}
}
?>
